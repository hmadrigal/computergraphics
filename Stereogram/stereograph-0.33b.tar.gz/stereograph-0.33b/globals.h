#ifndef _GLOBALS_H_
#define _GLOBALS_H_

int stereograph_verbose;
int stereograph_error;
char * stereograph_include_dir;
  
#endif /* _GLOBALS_H_ */
