#include <math.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define PI M_PI
#define DIRECT 0
#define AUXIL  1

/* this struct is used to hold the graphics data used for input and output by the renderer */
struct GFX_DATA {
	/* measurements */
	int Width;
	int Height;

	/* RGB-Data, 24bit coding @ ONE 32 bit integer, standard eastern orientation
           (left to right, top to bottom) */
	int *Data;
};

typedef double point[3];
typedef void (*BFunction)();
typedef double (*ZFunction)(double x, double y);
typedef void  (*PFunction)(point p, double x, double y);

extern double max(double x, double y);
extern double min(double x, double y);

extern void init_graphic_window(int w, int h, int mode);

extern void scale(double a);
extern void translation(double a, double b, double c);
extern void rotate(point p, point q);

extern void rotation_angles(double theta, double phi, double psi);

extern void mesh(point *p, int h, int i, int j);
extern void put_pixel(int x, int y, int r, int g, int b);

extern void build(BFunction bfunct);
extern void light(ZFunction zfunct);
extern void graph(PFunction pfunct,
		  double xi, double xs, int nx,
                  double yi, double ys, int ny);

extern void set_range(char c, double x1, double x2);

extern void set_color_levels();
extern void set_grey_levels();

extern int width, height, color_range;
extern double X1, X2, Y1, Y2, Z1, Z2;
extern int * pixel_color;
extern struct GFX_DATA * global_gfx;
